This ZIP file contains the Win32 DEC Alpha compiled versions of ref_soft.dll, 
ref_gl.dll, gameaxp.dll, and q2test.exe.  In order to work you have to copy
these files over the existing x86 binaries (with the exception of gameaxp.dll,
which coexists peacefully with gamex86.dll).  Because of this, make sure that
you have backups of these files before overwriting them!

The DEC Alpha binaries have NOT been thoroughly tested!  I've tested them on
an Enorex DEC Alpha with a 500MHz 21164 installed, running WinNT 4.0 with SP3
installed.  Both software rendering and OpenGL rendering work fine, but the
OpenGL ref has only been tested on a 3DLabs Permedia2 board.  I'm reasonably
confident that it will work in some fashion with a PowerStorm board.  I'm
also reasonably confident that Q2TEST will NOT work with any other OpenGL
accelerators available on DEC Alpha systems.

It is highly unlikely that Q2TEST for the DEC Alpha will work on a 21064 AXP
system.

For you techies out there, these files were compiled using MSVC 5.0 with SP2
installed, full optimizations enabled, release build, and targeting the 
21164 processor.

If you have problems, send mail to me at bwh@idsoftware.com describing the
problem and the type of system that you have.

Have fun!

