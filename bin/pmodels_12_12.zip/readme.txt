
 TexPaint and Playermodels
 -------------------------

 Here is some data to help you create playermodel skins. I've included
both a crouching and standing frame for each sex.

 You can use TexPaint as a model viewer, but if you wish to use TexPaint to paint 
on a model, you will need a GL card which supports 24 bit textures, and a 24 bit 
framebuffer. Otherwise if you click to paint on a model, the pixels will show up 
in random places.

 -Christian
 Sept.12.1997