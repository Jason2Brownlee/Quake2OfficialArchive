// Copyright (c) ZeniMax Media Inc.
// Licensed under the GNU General Public License 2.0.

#include "../g_local.h"
#include "bot_think.h"

/*
================
Bot_BeginFrame
================
*/
void Bot_BeginFrame( edict_t * bot ) {

}

/*
================
Bot_EndFrame
================
*/
void Bot_EndFrame( edict_t * bot ) {

}
