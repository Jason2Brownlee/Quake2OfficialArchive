
12/27/97 Quake 2 v3.07 patch release notes:

This is an interim release that fixes the most serious problems with
the initial release of Quake 2.

There are four files that must be replaced to upgrade to 3.07:

in the main quake2 directory:

quake2.exe
ref_soft.dll
ref_gl.dll

and in the quake2/baseq2 directory:

gamex86.dll

