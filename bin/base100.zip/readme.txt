This is a test of base100, all three base levels tied together
in one huge map. You must have 32megs to play this map. 

Unzip the map into quake2\baseq2\maps directory.

There will be a server running here at;
 
alpha2.idsoftware.com

We want to stress test this baby.

This is a closed test of this map do not distribute it. 

If you have any comments about the level drop me e-mail.
twillits@idsoftware.com
